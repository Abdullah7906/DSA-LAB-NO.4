class Node {
public:
    int data;
    Node* next;

    Node(int value);  // Constructor to initialize a node with value
};
