#include "Node.h"

// Constructor to initialize a node with a given value
Node::Node(int value) {
    data = value;
    next = nullptr;
}
