// Node.cpp
#include "Node.h"

// Constructor definition
Node::Node(int value) : data(value), next(nullptr) {}
