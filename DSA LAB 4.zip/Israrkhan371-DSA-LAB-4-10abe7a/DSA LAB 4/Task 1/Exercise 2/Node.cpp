// Node.cpp
#include "Node.h"

// Constructor to initialize node with a character value
Node::Node(char value) {
    data = value;
    next = nullptr;
}
